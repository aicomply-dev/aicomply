# Quick Start Guide - AI Act Legal Advisor

## Installation (3 steps)

```bash
# 1. Extract the package
tar -xzf ai-act-legal-advisor-skill.tar.gz
cd ai-act-legal-advisor-package

# 2. Run the installer
bash install.sh

# 3. Start using Claude Code
cd ~/your-project
claude
```

## Usage

### Invoke the skill explicitly:
```bash
/ai-act-legal-advisor
```

### Or just ask questions (auto-triggers):
- "Is our AI system high-risk under the EU AI Act?"
- "What are the prohibited AI practices?"
- "What penalties apply for non-compliance?"
- "Do we need a conformity assessment?"
- "What are the GPAI model obligations?"
- "When do the high-risk requirements take effect?"

## Key Topics Covered

✅ **Scope & Classification**
- System in-scope determination
- High-risk classification (Annex III)
- Prohibited practices (Article 5)
- Risk tier assessment

✅ **Obligations**
- Provider requirements
- Deployer requirements
- GPAI model obligations
- Transparency requirements

✅ **Compliance**
- Technical documentation (Annex IV)
- Conformity assessment procedures
- Registration requirements
- Quality management systems

✅ **Enforcement**
- Penalty frameworks
- Fine calculations
- Timeline compliance
- Post-market monitoring

## Response Format

Every response includes:
1. **Legal Disclaimer** (mandatory)
2. **Direct Answer** with Article citations
3. **Official Act Text** (exact quotes)
4. **Advisory Perspectives** (White & Case + Bird & Bird)
5. **Practical Implications**
6. **Key Dates** (if relevant)
7. **Related Articles** (cross-references)

## Key Compliance Dates

| Milestone | Date |
|-----------|------|
| Prohibited practices enforcement | 2 February 2025 |
| GPAI obligations | 2 August 2025 |
| High-risk (Annex I products) | 2 August 2025 |
| High-risk (Annex III systems) | 2 August 2026 |
| Full application | 2 August 2027 |

## Penalty Quick Reference

| Violation Type | Maximum Fine |
|---------------|-------------|
| Prohibited practices (Art. 5) | EUR 35M or 7% revenue |
| High-risk non-compliance | EUR 15M or 3% revenue |
| Information obligations | EUR 7.5M or 1.5% revenue |

## Sources

The skill cross-references three authoritative sources:

1. **EU Regulation 2024/1689** - Official legislative text (28 sections)
2. **White & Case Handbook** (May 2025) - Practical compliance guide
3. **Bird & Bird Guide** (April 2025) - Legal analysis with international scope

All sources are included in this package (~2MB total).

## Troubleshooting

**Skill doesn't work:**
```bash
# Verify installation
ls ~/.claude/skills/ai-act-legal-advisor/SKILL.md

# Check sources path (default)
ls ~/projects/tgrc-test/Aiact/AIACT/
```

**Need to change sources path:**
```bash
# Edit the skill file
nano ~/.claude/skills/ai-act-legal-advisor/SKILL.md

# Update line 20 to your actual path
```

## Support

For issues with:
- **Claude Code**: https://github.com/anthropics/claude-code/issues
- **This skill**: Check README.md for detailed troubleshooting

---

**Legal Notice**: This skill provides analysis based on EU Regulation 2024/1689 and interpretive guidance. It does not constitute legal advice. Consult qualified legal counsel for compliance decisions.
