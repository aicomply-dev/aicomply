# AI Act Legal Advisor - Claude Code Skill

## Overview

This Claude Code skill provides EU AI Act (Regulation 2024/1689) legal guidance by cross-referencing three authoritative sources:

1. **Official EU Regulation 2024/1689** legislative text (28 section files)
2. **White & Case** practical compliance handbook (May 2025) - 414KB
3. **Bird & Bird** legal guide (April 2025) - 236KB

Total package size: ~2MB

## Installation Instructions

### Step 1: Install the Skill

Copy the skill to your Claude Code skills directory:

```bash
# Create skills directory if it doesn't exist
mkdir -p ~/.claude/skills

# Copy the skill
cp -r skill ~/.claude/skills/ai-act-legal-advisor
```

### Step 2: Install Source Documents

You have two options:

#### Option A: Use the same path as the original (recommended if possible)

```bash
# Create the directory structure
mkdir -p ~/projects/tgrc-test/Aiact

# Copy source documents
cp -r aiact-sources ~/projects/tgrc-test/Aiact/AIACT
```

#### Option B: Use a custom path

1. Copy the sources to your preferred location:
```bash
# Example: copy to your home directory
cp -r aiact-sources ~/aiact-legal-sources
```

2. Update the skill file to point to the new location:
```bash
# Edit the skill file
nano ~/.claude/skills/ai-act-legal-advisor/SKILL.md

# Find line 20 and update the path:
# All sources located in: `/your/custom/path/aiact-legal-sources/`
```

### Step 3: Verify Installation

1. Start Claude Code in any project
2. Type `/ai-act-legal-advisor` to invoke the skill
3. Or ask any question about EU AI Act compliance

The skill will automatically trigger when you ask about:
- EU AI Act compliance
- Risk classification
- Prohibited practices
- Penalties and fines
- GPAI requirements
- Conformity assessment
- Any legal questions about Regulation EU 2024/1689

## Usage Examples

```bash
# Invoke the skill explicitly
/ai-act-legal-advisor

# Or just ask questions (skill auto-triggers):
"Is our AI system high-risk under the EU AI Act?"
"What are the penalties for prohibited AI practices?"
"What documentation do we need for GPAI models?"
```

## Package Contents

```
ai-act-legal-advisor-package/
├── README.md (this file)
├── skill/
│   └── SKILL.md (10.6KB - the skill definition)
└── aiact-sources/
    ├── AI Act Handbook_White and Case_250625_232256_May 2025.md (414KB)
    ├── European Union Artificial Intelligence Act Guide_Bird and Bird_April 2025.md (236KB)
    ├── aiact.md (648KB - full legislative text)
    └── sections/ (28 section files, 740KB total)
        ├── 00_TABLE_OF_CONTENTS.md
        ├── 01_preamble.md
        ├── 02_chapter_01_general_provisions.md
        ├── 03_chapter_02_prohibited_ai_practices.md
        ├── 04_chapter_03_high_risk_ai_systems.md
        └── ... (23 more section files)
```

## Requirements

- Claude Code CLI installed
- Bash/Zsh shell
- ~2MB disk space

## Troubleshooting

**Skill doesn't trigger:**
- Check that the skill is in `~/.claude/skills/ai-act-legal-advisor/SKILL.md`
- Restart Claude Code

**Can't find source documents:**
- Verify the path in line 20 of `SKILL.md` matches where you installed the sources
- Check that all files are readable: `ls -la ~/projects/tgrc-test/Aiact/AIACT/`

**Skill triggers but errors when reading files:**
- Ensure the source documents path in SKILL.md is correct
- Check file permissions: `chmod -R 644 ~/projects/tgrc-test/Aiact/AIACT/*`

## License

This skill and the source documents are for educational and compliance purposes. The AI Act text is official EU legislation (public domain). The advisory documents (White & Case, Bird & Bird) are used for compliance guidance.

## Legal Disclaimer

This skill provides analysis based on EU Regulation 2024/1689 and interpretive guidance. It does not constitute legal advice. Consult qualified legal counsel for decisions affecting your organization.
