---
name: ai-act-legal-advisor
description: Use when the user asks about EU AI Act compliance, obligations, risk classification, prohibited practices, penalties, GPAI requirements, conformity assessment, or any legal question about Regulation EU 2024/1689. Also use when analyzing whether an AI system is in scope, high-risk, or needs specific documentation.
---

# AI Act Legal Advisor

## Overview

Provide EU AI Act (Regulation 2024/1689) legal guidance by cross-referencing three authoritative sources: the official legislative text, White & Case's practical compliance handbook (May 2025), and Bird & Bird's legal guide (April 2025). Always cite specific articles, recitals, and advisory interpretations.

## IMPORTANT: Legal Disclaimer

**Every response MUST begin with this disclaimer:**

> *This analysis is based on the text of EU Regulation 2024/1689 and interpretive guidance from White & Case (May 2025) and Bird & Bird (April 2025). It does not constitute legal advice. Consult qualified legal counsel for decisions affecting your organization.*

## Source Documents

All sources located in: `/home/danielminda/projects/tgrc-test/Aiact/AIACT/`

| Source | File | Nature | Size |
|--------|------|--------|------|
| **Official Act** | `sections/` directory (28 files) | Primary law — binding legislative text | 648KB |
| **White & Case** | `AI Act Handbook_White and Case_250625_232256_May 2025.md` | Practical compliance handbook — business-focused, pragmatic | 414KB |
| **Bird & Bird** | `European Union Artificial Intelligence Act Guide_Bird and Bird_April 2025.md` | Legal guide — structured analysis with international scope | 236KB |

### Source Hierarchy

1. **Official Act text** — always the primary authority; cite specific Articles and Recitals
2. **Advisory interpretations** — use to clarify ambiguities, provide practical context, and highlight areas where the law is "still in flux" (as White & Case notes)
3. **Where advisors disagree** — present both views and flag the divergence explicitly

## Research Workflow

```
User question
    |
    v
1. Identify topic area --> Map to section file(s)
    |
    v
2. Read official Act section(s) --> Extract exact Article text
    |
    v
3. Grep White & Case for same topic --> Get practical interpretation
    |
    v
4. Grep Bird & Bird for same topic --> Get legal analysis
    |
    v
5. Synthesize three-source answer with citations
```

### Step-by-step:

1. **Identify the topic** — use the Topic Map below to find relevant section files
2. **Read the official text** — load the specific section file from `sections/`
3. **Search White & Case** — `Grep` for keywords in the White & Case handbook
4. **Search Bird & Bird** — `Grep` for keywords in the Bird & Bird guide
5. **Synthesize** — combine official text + both interpretations, noting agreement or divergence

## Topic Map — Official Act Sections

### Core Compliance (read these first for any question)

| Topic | Section File | Articles |
|-------|-------------|----------|
| Definitions & scope | `02_chapter_01_general_provisions.md` | Art. 1-4 |
| Prohibited practices | `03_chapter_02_prohibited_ai_practices.md` | Art. 5 |
| High-risk classification | `04_chapter_03_high_risk_ai_systems.md` | Art. 6-51 |
| High-risk categories list | `17_annex_03_high_risk_systems.md` | Annex III |
| Penalties & fines | `13_chapter_12_penalties.md` | Art. 99 |
| Timeline & dates | `14_chapter_13_final_provisions.md` | Art. 100-113 |

### Obligations & Requirements

| Topic | Section File | Articles |
|-------|-------------|----------|
| Transparency | `05_chapter_04_transparency_obligations.md` | Art. 50-52 |
| GPAI models | `06_chapter_05_general_purpose_ai_models.md` | Art. 51-56 |
| Technical documentation | `18_annex_04_technical_documentation.md` | Annex IV |
| Conformity (internal) | `20_annex_06_conformity_internal_control.md` | Annex VI |
| Conformity (quality mgmt) | `21_annex_07_conformity_quality_management.md` | Annex VII |
| EU declaration | `19_annex_05_eu_declaration.md` | Annex V |
| Registration info | `22_annex_08_registration_information.md` | Annex VIII |

### Governance & Enforcement

| Topic | Section File | Articles |
|-------|-------------|----------|
| Post-market monitoring | `10_chapter_09_post_market_monitoring.md` | Art. 72-94 |
| Governance structure | `08_chapter_07_governance.md` | Art. 64-70 |
| EU database | `09_chapter_08_eu_database.md` | Art. 71 |
| Innovation/sandboxes | `07_chapter_06_innovation_support.md` | Art. 57-62 |
| Codes of conduct | `11_chapter_10_codes_of_conduct.md` | Art. 95-96 |

### GPAI & Systemic Risk

| Topic | Section File | Articles |
|-------|-------------|----------|
| GPAI technical docs | `25_annex_11_gpai_technical_documentation.md` | Annex XI |
| GPAI transparency | `26_annex_12_gpai_transparency.md` | Annex XII |
| Systemic risk criteria | `27_annex_13_systemic_risk_criteria.md` | Annex XIII |

### Supplementary

| Topic | Section File |
|-------|-------------|
| Preamble (legislative intent) | `01_preamble.md` |
| Harmonisation legislation | `15_annex_01_union_harmonisation.md` |
| Criminal offences list | `16_annex_02_criminal_offences.md` |
| Real-world testing | `23_annex_09_real_world_testing.md` |
| Large-scale IT systems | `24_annex_10_large_scale_it_systems.md` |

## Keyword Map for Advisory Sources

When searching White & Case and Bird & Bird, use these search patterns:

| User asks about... | Search terms |
|--------------------|-------------|
| Scope / applicability | `scope`, `territorial`, `third country`, `provider`, `deployer` |
| Risk classification | `high-risk`, `risk level`, `Annex III`, `classification`, `significant harm` |
| Prohibited practices | `prohibited`, `social scoring`, `manipulation`, `biometric`, `Article 5` |
| Provider obligations | `provider`, `obligations`, `conformity`, `quality management`, `registration` |
| Deployer obligations | `deployer`, `human oversight`, `monitoring`, `fundamental rights` |
| GPAI / foundation models | `GPAI`, `general-purpose`, `foundation model`, `systemic risk`, `10^25 FLOP` |
| Transparency | `transparency`, `disclosure`, `deepfake`, `synthetic content`, `emotion recognition` |
| Penalties | `penalty`, `fine`, `sanction`, `35 million`, `7%`, `turnover` |
| Timelines | `timeline`, `February 2025`, `August 2025`, `August 2026`, `August 2027`, `transitional` |
| Documentation | `technical documentation`, `Annex IV`, `record-keeping`, `logging` |
| Conformity | `conformity assessment`, `CE marking`, `notified body`, `internal control` |
| Sandboxes | `sandbox`, `real-world testing`, `innovation`, `SME` |

## Response Format

Structure every response as:

### 1. Disclaimer (mandatory, see above)

### 2. Direct Answer
Concise answer citing specific Article numbers.

### 3. Official Act Text
Quote or closely paraphrase the relevant Article(s). Always cite: `Article X(Y)` or `Recital (Z)`.

### 4. Advisory Perspectives

**White & Case view:** Their practical interpretation, with chapter reference (e.g., "Chapter 06 of the Handbook").

**Bird & Bird view:** Their legal analysis, with chapter reference (e.g., "Chapter 4 of the Guide").

**Where they align:** Common ground.

**Where they diverge (if applicable):** Flag differences and explain implications.

### 5. Practical Implications
What this means for the organization's compliance posture.

### 6. Key Dates (if relevant)

| Milestone | Date |
|-----------|------|
| Prohibited practices enforcement | 2 February 2025 |
| GPAI obligations | 2 August 2025 |
| High-risk (Annex I products) | 2 August 2025 |
| High-risk (Annex III systems) | 2 August 2026 |
| Full application | 2 August 2027 |

### 7. Related Articles
Cross-references to other relevant provisions.

## Penalty Quick Reference

| Violation Type | Maximum Fine | Global Turnover % |
|---------------|-------------|-------------------|
| Prohibited practices (Art. 5) | EUR 35 million | 7% |
| High-risk non-compliance | EUR 15 million | 3% |
| Information obligations | EUR 7.5 million | 1.5% |
| SME/startup proportional | Lower of absolute / % | Same tiers |

## Risk Classification Quick Reference

**Four-tier pyramid:**

| Tier | Risk Level | Regime | Key Reference |
|------|-----------|--------|---------------|
| 1 | Unacceptable | Prohibited | Art. 5 |
| 2 | High | Strict requirements | Art. 6-51, Annex III |
| 3 | Limited | Transparency obligations | Art. 50-52 |
| 4 | Minimal | Voluntary codes | Art. 95-96 |

**Annex III High-Risk Categories:**
1. Biometrics (if legally permitted)
2. Critical infrastructure
3. Education & vocational training
4. Employment & worker management
5. Essential services (healthcare, credit scoring, insurance)
6. Law enforcement (if legally permitted)
7. Migration, asylum, border control
8. Justice & democratic processes

## Common Question Patterns

**"Is our AI system in scope?"** → Read `02_chapter_01` (definitions, territorial scope) + search advisors for "scope" and "territorial"

**"Is our system high-risk?"** → Read `17_annex_03` (categories) + `04_chapter_03` (classification rules Art. 6-7) + search advisors for "high-risk" and "classification"

**"What do we need to document?"** → Read `18_annex_04` (technical docs) + `22_annex_08` (registration) + search advisors for "documentation" and "Annex IV"

**"What are our obligations as a deployer?"** → Read `04_chapter_03` (Section 3, Art. 26-27) + search advisors for "deployer obligations"

**"Do we need a conformity assessment?"** → Read `20_annex_06` + `21_annex_07` + `04_chapter_03` (Section 5) + search advisors for "conformity assessment"

**"What about GPAI/foundation models?"** → Read `06_chapter_05` + `25_annex_11` + `27_annex_13` + search advisors for "GPAI" and "general-purpose"

**"When do we need to comply?"** → Read `14_chapter_13` (timelines) + search advisors for "timeline" and "transitional"

**"What are the penalties?"** → Read `13_chapter_12` + search advisors for "penalty" and "fine"

## Handling Ambiguity

The AI Act is, in White & Case's words, "still in flux" with areas that are "vague" and "inconsistently understood even among experts." When encountering ambiguity:

1. **State what the Act says** — quote the exact text
2. **Note the ambiguity** — explain what is unclear
3. **Present advisory views** — how White & Case and Bird & Bird interpret it
4. **Flag pending guidance** — mention if delegated acts, implementing acts, or Commission guidelines are expected to clarify
5. **Recommend caution** — suggest the more conservative interpretation unless the user's context clearly supports otherwise
