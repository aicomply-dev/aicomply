#!/bin/bash
# AI Act Legal Advisor - Installation Script for Claude Code

set -e

echo "============================================"
echo "AI Act Legal Advisor - Installation Script"
echo "============================================"
echo ""

# Check if Claude Code is installed
if ! command -v claude &> /dev/null; then
    echo "⚠️  Warning: Claude Code CLI not found in PATH"
    echo "   Install from: https://claude.ai/code"
    echo ""
fi

# Create skills directory
echo "Creating ~/.claude/skills directory..."
mkdir -p ~/.claude/skills

# Install skill
echo "Installing AI Act Legal Advisor skill..."
cp -r skill ~/.claude/skills/ai-act-legal-advisor
echo "✓ Skill installed to: ~/.claude/skills/ai-act-legal-advisor/"

# Prompt for source documents location
echo ""
echo "Choose source documents installation option:"
echo "  1) Install to ~/projects/tgrc-test/Aiact/AIACT/ (default path, no config needed)"
echo "  2) Install to custom path (requires updating SKILL.md)"
echo ""
read -p "Enter choice [1 or 2]: " choice

case $choice in
    2)
        read -p "Enter custom path (e.g., ~/aiact-sources): " custom_path
        eval custom_path="$custom_path"  # Expand ~ if present

        echo "Installing sources to: $custom_path"
        mkdir -p "$custom_path"
        cp -r aiact-sources/* "$custom_path/"

        echo ""
        echo "⚠️  IMPORTANT: You must update the skill file!"
        echo "   Edit: ~/.claude/skills/ai-act-legal-advisor/SKILL.md"
        echo "   Line 20: Change path to: $custom_path"
        echo ""
        echo "   Run this command:"
        echo "   nano ~/.claude/skills/ai-act-legal-advisor/SKILL.md"
        ;;
    *)
        echo "Installing sources to: ~/projects/tgrc-test/Aiact/AIACT/"
        mkdir -p ~/projects/tgrc-test/Aiact
        cp -r aiact-sources ~/projects/tgrc-test/Aiact/AIACT
        echo "✓ Sources installed (no config changes needed)"
        ;;
esac

echo ""
echo "============================================"
echo "✅ Installation Complete!"
echo "============================================"
echo ""
echo "Usage:"
echo "  1. Start Claude Code in any project"
echo "  2. Type: /ai-act-legal-advisor"
echo "  3. Or ask: 'What are the EU AI Act penalties?'"
echo ""
echo "The skill auto-triggers for EU AI Act compliance questions."
echo ""
